#!/usr/bin/env python

import os

os.environ.setdefault('MESSAGE', '')
if os.environ.get('MESSAGE') == '':
    print('Hello: message not found')
else:
    print('Hello: '+os.environ.get('MESSAGE'))

