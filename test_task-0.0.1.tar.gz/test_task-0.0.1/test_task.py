#!/usr/bin/env python
x=''

if x=="":
    print("Hello: message not found")
else:
    print('Hello: '+x)

